print("Bienvenido al cotizador de SportMarket")
productos = {"Bicicleta de montaña": 500000, "Balón de fútbol": 35000}

producto = input("Producto: ")
cantidad = int(input("Cantidad: "))

if producto in productos:
    total = productos[producto] * cantidad
    print(f"Total: ${total}")
else:
    print("Producto no disponible")

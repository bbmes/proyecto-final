from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def inicio():
    productos = [
        {"nombre": "Bicicleta de montaña", "precio": 500000},
        {"nombre": "Balón de fútbol", "precio": 35000}
    ]
    return render_template("index.html", productos=productos)

if __name__ == "__main__":
    app.run(debug=True)


class Producto:
    def __init__(self, nombre, categoria, precio, estado):
        self.nombre = nombre
        self.categoria = categoria
        self.precio = precio
        self.estado = estado

    def __str__(self):
        return f"{self.nombre} ({self.estado}) - ${self.precio}"

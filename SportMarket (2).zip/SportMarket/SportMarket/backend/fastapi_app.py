from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

productos = {
    "bicicleta": 500000,
    "balon": 35000
}

class Compra(BaseModel):
    producto: str
    cantidad: int

@app.post("/cotizar")
def cotizar(compra: Compra):
    precio = productos.get(compra.producto.lower())
    if precio:
        total = precio * compra.cantidad
        return {"total": total}
    return {"error": "Producto no disponible"}

@app.get("/")
def home():
    return {"mensaje": "Bienvenido a la API de SportMarket"}

from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def inicio():
    productos = [
        {"nombre": "Bicicleta de montaña", "precio": 500000},
        {"nombre": "Balón de fútbol", "precio": 35000}
    ]
    return render_template("index.html", productos=productos)

@app.route("/carrito")
def carrito():
    return render_template("carrito.html")

@app.route("/contacto")
def contacto():
    return render_template("contacto.html")

if __name__ == "__main__":
    app.run(debug=True)

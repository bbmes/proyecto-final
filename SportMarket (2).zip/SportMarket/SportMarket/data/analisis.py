import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("productos.csv")

resumen = df.groupby("categoria").agg({
    "venta_id": "count",
    "precio_total": "sum"
})

print(resumen)

resumen["precio_total"].plot(kind="bar", title="Ingresos por categoría", color="green")
plt.ylabel("Ingresos ($)")
plt.show()

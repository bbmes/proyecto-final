const express = require('express');
const nodemailer = require('nodemailer');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(express.static('public'));  // Para servir el archivo HTML desde la carpeta "public"

app.post('/enviar_correo', (req, res) => {
    const { nombre, correo, asunto, mensaje } = req.body;

    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'tu_correo@gmail.com', // Tu correo de Gmail
            pass: 'tu_contraseña' // Contraseña de tu cuenta de Gmail o contraseña de aplicación
        }
    });

    const mailOptions = {
        from: correo, 
        to: 'correo_destino@example.com', // Tu correo de destino
        subject: asunto,
        text: `De: ${nombre} <${correo}>\n\nMensaje:\n${mensaje}`
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.log(error);
            return res.status(500).json({ message: 'Error al enviar el correo' });
        }
        console.log('Correo enviado: ' + info.response);
        return res.status(200).json({ message: 'Correo enviado con éxito' });
    });
});

app.listen(port, () => {
    console.log(`Servidor escuchando en http://localhost:${port}`);
});

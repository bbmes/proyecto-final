function agregarCarrito(producto, precio) {
  alert(producto + " agregado al carrito. Precio: $" + precio);
}


function abrirModal(id) {
  document.getElementById(id).style.display = "block";
}

function cerrarModal(id) {
  document.getElementById(id).style.display = "none";
}

// cerrar botones 



// botones de descripcion del producto
  function toggleDescripcion(button) {
    const descripcion = button.nextElementSibling;
    if (descripcion.style.display === "none" || descripcion.style.display === "") {
      descripcion.style.display = "block";
      button.textContent = "Ocultar descripción";
    } else {
      descripcion.style.display = "none";
      button.textContent = "Descripción del producto";
    }
  }


  // Muestra la notificación al agregar al carrito
  function mostrarNotificacion() {
    const notificacion = document.getElementById("notificacion-carrito");
    notificacion.style.display = "block";

    // Ocultar después de 3 segundos
    setTimeout(() => {
      notificacion.style.display = "none";
    }, 3000);
  }

  // Asignar evento a todos los botones de pagar
  document.querySelectorAll(".btn-pagar").forEach(boton => {
    boton.addEventListener("click", mostrarNotificacion);
  });

  // notificacion de el mensaje fue enviado correctamente
    function enviarMensaje(event) {
    event.preventDefault();

    // Aquí puedes agregar integración real con backend o servicios como Formspree, EmailJS, etc.
    alert("📩 Tu mensaje ha sido enviado correctamente. ¡Gracias por contactarnos!");
    
    // Limpiar formulario
    event.target.reset();
    }

